import {useState} from'react'
import { ScrollView, View, Text, Image, TouchableOpacity, TextInput } from 'react-native'
import{ styles} from './styles'

export default function App() {
  const [emailField, setEmailField] = useState<string>('')
  const [passwordField, setPasswordField] = useState<string>('')
  const [tela, setTela ] = useState<string>('true')
  const [esqueciMinhaSenha, setEsqueciMinhaSenha] = useState<string>('false')
  const [cadastrar, setCadastrar] = useState<string>('false')
  const [entrar, setEntrar] = useState<string>('false')

 const handleButton = () => {
    
  }
  
  //Função de esqueci minha senha
  const handleForgoButton = () => {
    setTela('false')
    setEsqueciMinhaSenha('true')
  }

  //Função cadastre-se
  const handleBackLoginButton = () => {
    setTela('true')
    setEsqueciMinhaSenha('false')
    setCadastrar('false')
    setEntrar('false')
  }
  
  //Função do Botão Entrar
  const handleLoginButton = () => {
    setTela('false')
    setEntrar('true')
  }

  // Função do cadastre-se
  const handleSignUpButton = () => {
    setTela('false')
    setCadastrar('true')
  }

  const handleFilmeButton = () => {
    alert('qualquer coisa')
  }

  const handleSerieButton = () => {
    alert('qualquer coisa')
  }

  return (
    <ScrollView style={styles.scrollview}>

    { tela == 'true' &&
    <>
    
      <View style={styles.container}>
        <Image style={styles.logo} source={require('./assets/icon.png')}/>
        <Text style={styles.h1}>Sistema de Login</Text>
        <Text style={styles.h2}>Bem vindo(a)! Digite seus dados abaixo.</Text>
        
        <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Email</Text>
          <TextInput 
          style={styles.inputField}
          placeholder='Digite seu email'
          placeholderTextColor='#999'
          value={emailField}
          onChangeText={t => setEmailField(t)}
          autoCapitalize='none'
          keyboardType='email-address'
          />
        </View>

        <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Senha</Text>
          <TextInput
           style={styles.inputField}
           placeholder='**********' 
           placeholderTextColor='#999'
           value={passwordField}
           onChangeText={t => setPasswordField(t)}
           autoCapitalize='none'
           secureTextEntry
           />
        </View>

        <View style={styles.aditionals}>
          <TouchableOpacity style={styles.forgotBtnArea} onPress={handleForgoButton}>
            <Text style={styles.forgoBtnText}>Esqueci minha senha</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.button} onPress={handleLoginButton}>
          <Text style={styles.buttonText}>Entrar</Text>
        </TouchableOpacity>

        <View style={styles.signUpArea}>
          <Text style={styles.signUpText}>Não tem conta?</Text>
          <TouchableOpacity onPress={handleSignUpButton}>
            <Text style={styles.signUpBtnText}>Cadastre-se</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footerArea}>
          <Text style={styles.footerText}>Criado por Fulano</Text>
        </View>
      </View>

      </>
    }
    { esqueciMinhaSenha == 'true' &&
    <>
      <View>
        
        <View style={styles.container}>
         <Image style={styles.logo} source={require('./assets/icon.png')}/>
         <Text style={styles.h2}>Redefinição de senha</Text>
         <Text>Email</Text>

         <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Email</Text>
          <TextInput 
          style={styles.inputField}
          placeholder='Digite seu email'
          placeholderTextColor='#999'
          value={emailField}
          onChangeText={t => setEmailField(t)}
          autoCapitalize='none'
          keyboardType='email-address'
          />
        </View>
         <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Nova Senha</Text>
          <TextInput
           style={styles.inputField}
           placeholder='Digite sua nova senha' 
           placeholderTextColor='#999'
           value={passwordField}
           onChangeText={t => setPasswordField(t)}
           autoCapitalize='none'
           secureTextEntry
           />
        </View>
          <TouchableOpacity style={styles.button} onPress={handleBackLoginButton}>
          <Text style={styles.buttonVolte}>Voltar</Text>
        </TouchableOpacity>
          </View>
      </View>
    </>
    }
    { cadastrar == 'true' &&
    <>
      <View style={styles.container}>
        <Image style={styles.logo} source={require('./assets/icon.png')}/>
        <Text style={styles.h1}>Cadastre-se</Text>
        <Text style={styles.h2}>Bem vindo(a)! Digite seus dados abaixo.</Text>
        
        <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Email</Text>
          <TextInput 
          style={styles.inputField}
          placeholder='Digite seu email'
          placeholderTextColor='#999'
          value={emailField}
          onChangeText={t => setEmailField(t)}
          autoCapitalize='none'
          keyboardType='email-address'
          />
        </View>

        <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Senha</Text>
          <TextInput
           style={styles.inputField}
           placeholder='Crie uma senha' 
           placeholderTextColor='#999'
           value={passwordField}
           onChangeText={t => setPasswordField(t)}
           autoCapitalize='none'
           secureTextEntry
           />
        </View>
      </View>
      <View style={styles.inputArea}>
          <Text style={styles.inputLabel}>Telefone</Text>
          <TextInput 
          style={styles.inputField}
          placeholder='Digite seu número de telefone'
          placeholderTextColor='#999'
          value={emailField}
          onChangeText={t => setEmailField(t)}
          autoCapitalize='none'
          keyboardType='email-address'
          />
        </View>
        <TouchableOpacity style={styles.button} onPress={handleBackLoginButton}>
          <Text style={styles.buttonVolte}>Voltar</Text>
        </TouchableOpacity>
    </>
    }
    { entrar == 'true' &&
    <>
      <View>
        <Text style={styles.movie}>Movie tops </Text>
        <TouchableOpacity style={styles.buttonF} onPress={handleFilmeButton}>
          <Text style={styles.buttonFilme}>Filme</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonS} onPress={handleSerieButton}>
          <Text style={styles.buttonSerie}>Séries</Text>
        </TouchableOpacity>
         <Text style={styles.sugestao}>Recomendados</Text>
         <Text style={styles.a}>Filmes</Text>
         <Image style={styles.vingadores} source={require('./assets/vingadores.jpeg')}/>
         <Text style={styles.a}>Séries</Text>
         <Image style={styles.vingadores} source={require('./assets/anne.jpeg')}/>
      </View>
      <TouchableOpacity style={styles.button} onPress={handleBackLoginButton}>
          <Text style={styles.buttonVolte}>Voltar</Text>
        </TouchableOpacity>
    </>
    }
    </ScrollView>
  )
}