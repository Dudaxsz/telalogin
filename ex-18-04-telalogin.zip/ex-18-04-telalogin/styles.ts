import { StyleSheet} from 'react-native'

export const styles = StyleSheet.create({
  scrollview:{
    backgroundColor:'#ffb2cc',
    paddingHorizontal: 15,
    paddingTop:40,
  },
  container:{
    alignItems:'center',

  },
  logo:{
    width: 150,
    height:150,
  },
  h1:{
    color:  '#000',
    fontSize:27,
    fontWeight: 'bold',
    paddingVertical: 10,

  },
  h2:{
    color: '#999',
    fontSize: 15,
  },
  inputArea:{
    width: '100%',
    paddingTop:20,
  },
  inputLabel:{
    color:'#777',
    fontSize:14,
    fontWeight:'bold',
    paddingBottom:7,
  },
  inputField:{
    color:'#000',
    borderWidth:2,
    borderRadius:5,
    borderColor:'#ddd',
    fontSize:15,
    padding:10,
  },
  aditionals:{
    width:'100%',
  },
  forgotBtnArea:{
    paddingVertical:20,
    alignSelf:'flex-end',
  },
  forgoBtnText:{
    fontSize:14,
    fontWeight:'bold',
    color:'#4162b7',
  },
  button:{
    backgroundColor:'#ff3399',
    width:'100%',
    padding:10,
    borderRadius:5,
    marginTop: 15
  },
  buttonText:{
    alignSelf:'center',
    color:  'white',
    fontSize:16,
  },
  signUpArea:{
    flexDirection:'row',
    marginTop:30,
  },
  signUpText:{
    fontSize:13,
    fontWeight:'bold',
    color:'#999',
  },
  signUpBtnText:{
    fontSize:13,
    fontWeight:'bold',
    color:'#4162b7',
    marginLeft:5,
  },
  footerArea:{
    marginVertical:30,
  },
  footerText:{
    fontSize:13,
    color:'#999',
  },
  buttonVolte: {
    alignSelf:'center',
    color:  'white',
  },
  containerforgot: {
    alignItems:'center',
  },
  movie: {
    marginLeft: 70,
    padding: 10,
    color: '#ffffff',
    fontSize: 30,
    fontWeight: 'bold',
  },
  buttonFilme: {
    marginLeft: 15,
    
  },
  buttonSerie: {
    marginLeft: 15,
    
  },
  buttonF: {
    backgroundColor:'#ff3399',
    width:'100%',
    padding:10,
    borderRadius:5,
  },
  buttonS: {
    backgroundColor:'#ff3399',
    width:'100%',
    padding:10,
    borderRadius:5,
    marginTop: 10,
  },
  sugestao: {
    marginLeft: 85,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 10,
  },
  a: {
    marginLeft: 15,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 14,
  },
  vingadores: {
    marginTop: 10,
    marginLeft: 5,
  },
  
})